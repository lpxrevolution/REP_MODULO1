package com.mycompany.lopezpastorruben_activitatevaluable;

public abstract class Contacte 
{
    String nom;
    int telefon;
    
    public Contacte(String nm, int tlf) //Constructor Conctacte
    {
        nom=nm;
        telefon = tlf;
    }
}
