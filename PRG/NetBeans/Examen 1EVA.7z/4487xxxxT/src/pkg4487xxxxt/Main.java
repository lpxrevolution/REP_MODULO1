package pkg4487xxxxt;

/**
 *
 * @author RubenLP_4487xxxxt
 */
public class EmpleadoED_44654545X {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
